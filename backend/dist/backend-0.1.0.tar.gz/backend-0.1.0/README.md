# Backend

FastAPI backend service.

pip install poetry
poetry install
poetry run dev --reload    